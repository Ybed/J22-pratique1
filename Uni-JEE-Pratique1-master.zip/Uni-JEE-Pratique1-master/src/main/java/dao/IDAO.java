package dao;

public interface IDAO {
    public double getData();
}
